---
name: 📚 General Issue
about: Discuss general topics, questions, or suggestions
title: "[GENERAL]"
labels: question
assignees: ''
---

**Topic**
> A clear and concise description of the topic or question.

**Details**
> Provide more details or context about your topic or question.

**Additional context**
> Add any other context or screenshots if necessary.
